
from moviepy.editor import VideoFileClip, TextClip, CompositeVideoClip

def create_clip(video_path, start, end, subtitle_text, out_path):
    video = VideoFileClip(video_path).subclip(start, end)
    subtitle = TextClip(subtitle_text, fontsize=24, color='white').set_duration(video.duration).set_pos('bottom')
    final = CompositeVideoClip([video, subtitle])
    final.write_videofile(out_path)
