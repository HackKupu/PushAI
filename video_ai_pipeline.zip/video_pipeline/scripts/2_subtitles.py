
import whisper

def transcribe(video_path, output_path):
    model = whisper.load_model("base")
    result = model.transcribe(video_path)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(result["text"])
