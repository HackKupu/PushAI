
from keybert import KeyBERT

def generate_hashtags(text):
    kw_model = KeyBERT()
    keywords = kw_model.extract_keywords(text, keyphrase_ngram_range=(1, 2), stop_words='english')
    tags = [f"#{kw[0].replace(' ', '')}" for kw in keywords[:10]]
    return tags
