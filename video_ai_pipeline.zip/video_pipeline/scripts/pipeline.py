
from scripts import (download_video, transcribe, detect_scenes, create_clip, generate_hashtags)

def run_pipeline(youtube_url):
    video_path = download_video(youtube_url)
    subtitle_path = transcribe(video_path)
    scenes = detect_scenes(video_path)
    for i, (start, end) in enumerate(scenes[:3]):
        subtitle_text = "..."  # To be extracted from subtitle file
        clip_path = f"data/clips/clip_{i}.mp4"
        create_clip(video_path, start, end, subtitle_text, clip_path)
