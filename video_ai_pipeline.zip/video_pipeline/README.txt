
# Video AI Pipeline

## Як користуватися
1. Встановити залежності: `pip install -r requirements.txt`
2. Запуск: `python scripts/pipeline.py`
3. Налаштування — в config/settings.yaml
4. Відео зберігаються у папці data/raw
5. Кліпи — у data/clips
6. Субтитри — у data/subtitles

## Етапи:
- 1_download.py — завантаження відео з YouTube
- 2_subtitles.py — розпізнавання мовлення (Whisper)
- 3_detect_highlights.py — виявлення сцен (PySceneDetect)
- 4_clip_and_sub.py — нарізка кліпів та субтитри
- 5_generate_meta.py — хештеги з KeyBERT
- 6_upload.py — завантаження на платформи (ще stub)
